# setup.py
from setuptools import setup

__author__ = 'Rares Miclaus Stoian'

setup(
    name="tvs",
    version='0.1',
    py_modules=['tvs'],
    description="A simple commandline",
)